webpackJsonp(["common"],{

/***/ "../../../../../src/app/models/passwordCredentials.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PasswordCredentials; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__userCredentials__ = __webpack_require__("../../../../../src/app/models/userCredentials.ts");
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();

var PasswordCredentials = (function (_super) {
    __extends(PasswordCredentials, _super);
    function PasswordCredentials() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PasswordCredentials;
}(__WEBPACK_IMPORTED_MODULE_0__userCredentials__["a" /* UserCredentials */]));

//# sourceMappingURL=passwordCredentials.js.map

/***/ }),

/***/ "../../../../../src/app/models/profileEntity.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ProfileEntity; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__identifiableEntity__ = __webpack_require__("../../../../../src/app/models/identifiableEntity.ts");
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();

var ProfileEntity = (function (_super) {
    __extends(ProfileEntity, _super);
    function ProfileEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return ProfileEntity;
}(__WEBPACK_IMPORTED_MODULE_0__identifiableEntity__["a" /* IdentifiableEntity */]));

//# sourceMappingURL=profileEntity.js.map

/***/ }),

/***/ "../../../../../src/app/models/user.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return User; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__profileEntity__ = __webpack_require__("../../../../../src/app/models/profileEntity.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__userContact__ = __webpack_require__("../../../../../src/app/models/userContact.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__passwordCredentials__ = __webpack_require__("../../../../../src/app/models/passwordCredentials.ts");
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();



var User = (function (_super) {
    __extends(User, _super);
    function User() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.credentials = new __WEBPACK_IMPORTED_MODULE_2__passwordCredentials__["a" /* PasswordCredentials */]();
        _this.contactInfo = new __WEBPACK_IMPORTED_MODULE_1__userContact__["a" /* UserContact */]();
        return _this;
    }
    return User;
}(__WEBPACK_IMPORTED_MODULE_0__profileEntity__["a" /* ProfileEntity */]));

//# sourceMappingURL=user.js.map

/***/ }),

/***/ "../../../../../src/app/models/userContact.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UserContact; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__identifiableEntity__ = __webpack_require__("../../../../../src/app/models/identifiableEntity.ts");
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();

var UserContact = (function (_super) {
    __extends(UserContact, _super);
    function UserContact() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.emailAddress = '';
        _this.cellNumber = '';
        _this.firstName = '';
        _this.lastName = '';
        return _this;
    }
    return UserContact;
}(__WEBPACK_IMPORTED_MODULE_0__identifiableEntity__["a" /* IdentifiableEntity */]));

//# sourceMappingURL=userContact.js.map

/***/ }),

/***/ "../../../../../src/app/models/userCredentials.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UserCredentials; });
var UserCredentials = (function () {
    function UserCredentials() {
    }
    return UserCredentials;
}());

//# sourceMappingURL=userCredentials.js.map

/***/ })

});
//# sourceMappingURL=common.chunk.js.map