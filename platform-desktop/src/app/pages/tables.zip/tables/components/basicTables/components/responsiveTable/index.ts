export * from './responsiveTable.component';
