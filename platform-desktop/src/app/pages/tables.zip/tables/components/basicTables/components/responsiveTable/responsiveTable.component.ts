import {Component} from '@angular/core';

@Component({
  selector: 'responsive-table',
  templateUrl: './responsiveTable.html',
})
export class ResponsiveTable {

  constructor() {
  }
}
